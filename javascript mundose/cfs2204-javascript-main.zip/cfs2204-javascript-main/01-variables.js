console.log("hola mundo")

const firstName = "Victoria"
let age = 26
const viveEnLatinoamerica = true

console.log(firstName)

console.log(firstName, age, viveEnLatinoamerica)

// puedo cambiar el valor de variable de las que fueron declaradas con "let"
age = 27

//puedo cambiar el valorde variable a otros tipos de datos
age = true
age = "veinte"


//tipos de datos
const lastName = "Lopez"//string
const birthYear = 1990 //number
let knowsJavascript = false //boolean 
const phone = null //no tiene telefono o no tenemos el dato
let address //definoad la variable pero despues le doy valor (undefined)

// Crear un archivo html y un archivo script.js vinculado.
// En el archivo crear tres variables:
// nombre: de tipo string
// edad: de tipo número
// viveEnAmérica: de tipo booleano
// Logear en consola las tres variables.

const nombre = "Juan";
let edad = 30;
let viveEnAmerica = true;

console.log(nombre);
console.log(edad);
console.log(viveEnAmerica);

console.log(nombre, edad, viveEnAmerica);