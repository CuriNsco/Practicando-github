let nota = prompt("Cual fue la nota?")

// Si la nota es menor cuatro, entonces desaprobo
//Si la nota es entre cuatro y siete entonces aprobo
// si la nota es mayor a 7 entonces promociono

if(nota < 4){
    alert("desaprobo")
}else if(nota < 7){
    alert("aprobo")
}else{
    alert("promociono")
}


//EJERCICIO
// Necesitamos diseñar un sistema que decida si una persona puede entrar o no a un club.
// Utilizando la estructura if-else y las interacciones crear un script que le pregunté al usuario qué edad tiene y que devuelva un alert cuyo mensaje depende de su edad:
// Si tiene menos de 16: no puede ingresar
// Si tiene entre 16 y 18: puede ingresar al club pero no puede pasar al bar.
// Si tiene 18 o más: puede ingresar al club y al bar.
