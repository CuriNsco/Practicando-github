alert("Hola mundo!")

let userName= prompt("Cual es tu nombre?")

let quiereEntrar = confirm("Queres ver la pagina?")