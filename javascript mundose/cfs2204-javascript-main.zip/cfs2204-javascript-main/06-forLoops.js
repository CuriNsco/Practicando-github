for(let i = 0; i<3; i++){
    console.log(i)
}

//PRIMER VUELTA
// i = 0, la condicion i<3 es verdadera >> hace console.log(0)
// ejecuta el aumentador, le suma 1 a i (i ahora vale 1)

//SEGUNDA VUELTA
//i = 1, la condicion i<3 es verdadera >> hace console.log(1)
// ejecuta el aumentador, le suma 1 a i (i ahora vale 2)

//TERCERA VUELTA
//i = 2, la condicion i<3 es verdadera >> hace console.log(2)
// ejecuta el aumentador, le suma 1 a i (i ahora vale 3)

//FINAL
//i=3, la condicion i<3 es FALSA >>>> FIN DEL LOOP

//Loop decreciente

console.log("Loop decreciente")

for(let i = 10; i>0; i--){
    console.log(i)
}

console.log("Loop negativos")

for(let i = 3; i>-10; i--){
    console.log(i)
}